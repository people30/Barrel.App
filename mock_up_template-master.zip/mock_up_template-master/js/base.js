function navFunc() {
    var mymenu = document.querySelector(".header_menu_sm");
    if (mymenu.style.maxHeight) {
        mymenu.style.maxHeight = null;
    }
    else {
        mymenu.style.maxHeight
            = mymenu.scrollHeight + "px";
    }
}